import java.sql.Connection;
import java.sql.DriverManager;

public class Database {
	public Connection connection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/world", "root", "manaswini");
			return connection;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}
}

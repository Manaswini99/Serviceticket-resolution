import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Ldoa {

	public static boolean checkSe(String user, String pass) {
		Database db = new Database();
		Connection con = db.connection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from credentials ");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (user.equals(rs.getString(1)) && pass.equals(rs.getString(2)) && "SE".equals(rs.getString(3))) {
					return true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public static boolean checkUser(String user, String pass) {
		Database db = new Database();
		Connection con = db.connection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from credentials ");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (user.equals(rs.getString(1)) && pass.equals(rs.getString(2)) && "USER".equals(rs.getString(3))) {
					return true;
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}

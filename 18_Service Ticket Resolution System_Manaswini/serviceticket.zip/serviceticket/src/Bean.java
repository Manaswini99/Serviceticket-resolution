
import java.sql.Date;
import java.time.LocalDate;

public class Bean {
	private int ticket_id;
	private String dept;
	private String prior;
	private String priority;
	private LocalDate start_date;
	private LocalDate completed_date;

	public Bean(int ticket_id, String dept, LocalDate start_date, LocalDate completed_date, String end_date,
			String description, String customer, String service_engineer, String acutal_priority, String status) {
		super();
		this.ticket_id = ticket_id;
		this.dept = dept;
		this.start_date = start_date;
		this.completed_date = completed_date;
		this.end_date = end_date;
		this.description = description;
		this.customer = customer;
		this.service_engineer = service_engineer;
		this.acutal_priority = acutal_priority;
		this.status = status;
	}

	private String end_date;
	private String description;
	private String customer;
	private String service_engineer;
	private String acutal_priority;
	private String status;

	public int getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(int ticket_id) {
		this.ticket_id = ticket_id;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getPrior() {
		return prior;
	}

	public void setPrior(String prior) {
		this.prior = prior;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public LocalDate getStart_date() {
		return start_date;
	}

	public void setStart_date(LocalDate start_date) {
		this.start_date = start_date;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public Bean(int ticket_id, String prior, String description, String customer, String service_engineer) {
		super();
		this.ticket_id = ticket_id;
		this.prior = prior;
		// this.start_date = start_date;
		// this.end_date = end_date;
		// this.status=status;
		this.description = description;
		this.customer = customer;
		this.service_engineer = service_engineer;
	}

	public Bean() {
		// TODO Auto-generated constructor stub
	}

	public String getService_engineer() {
		return service_engineer;
	}

	public void setService_engineer(String service_engineer) {
		this.service_engineer = service_engineer;
	}

	public String getAcutal_priority() {
		return acutal_priority;
	}

	public void setAcutal_priority(String acutal_priority) {
		this.acutal_priority = acutal_priority;
	}

	public LocalDate getCompleted_date() {
		return completed_date;
	}

	public void setCompleted_date(LocalDate completed_date) {
		this.completed_date = completed_date;
	}

}

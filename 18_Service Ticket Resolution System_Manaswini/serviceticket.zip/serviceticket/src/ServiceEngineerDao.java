import java.sql.Array;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ServiceEngineerDao {

	public static int completeTicket(String name) {
		Database db = new Database();
		Connection connection = db.connection();
		try {
			PreparedStatement preparedstatement = connection.prepareStatement("select * from  ticket_table");
			ResultSet resultset = preparedstatement.executeQuery();
			while (resultset.next()) {
				if (resultset.getString(6).equals(name) && resultset.getString(5).equals("ongoing")) {
					return resultset.getInt(1);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static void updateTicketStatus(int tid, String user) {
		Database db = new Database();
		Connection connection = db.connection();
		try {
			PreparedStatement preparedstatement = connection
					.prepareStatement("UPDATE ticket_table set Status=?,completed_date=? where Tid=?");
			preparedstatement.setString(1, "completed");
			preparedstatement.setDate(2, Date.valueOf(LocalDate.now()));
			preparedstatement.setInt(3, tid);
			preparedstatement.executeUpdate();
			preparedstatement.executeQuery();
			
			int workedon = 0;
			PreparedStatement ps1 = connection.prepareStatement("select * from service_engineer");
			ResultSet resultset = ps1.executeQuery();
			while (resultset.next()) {
				if (resultset.getString(2).equals(user)) {
					workedon = resultset.getInt(4);
				}
			}
			workedon = workedon + 1;
			PreparedStatement ps2 = connection.prepareStatement(
					"UPDATE service_engineer set tickets_workedon=?,cuurent_highpriority=? where name=? ");
			ps2.setInt(1, workedon);
			ps2.setInt(2, 0);
			ps2.setString(3, user);
			ps2.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static List<serviceticket.Bean> view(String user) {
		Database db = new Database();
		Connection connection = db.connection();
		List<serviceticket.Bean> ticketsworked = new ArrayList<serviceticket.Bean>();
		try {
			PreparedStatement preparedstatement = connection.prepareStatement("select * from  ticket_table");
			ResultSet resultset = preparedstatement.executeQuery();
			while (resultset.next()) {
				if (user.equals(resultset.getString(6))) {
					serviceticket.Bean a = new serviceticket.Bean();
					a.setTicket_id(resultset.getInt(1));
					a.setAcutal_priority(resultset.getString(2));
					a.setCustomer(resultset.getString(7));
					ticketsworked.add(a);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ticketsworked;
	}

	public static void assignPending(String name) throws SQLException, ClassNotFoundException {
		Database db = new Database();
		Connection connection = db.connection();
		PreparedStatement preparedstatement = connection.prepareStatement("select * from  pendingtickets ORDER BY start_date");
		ResultSet rss = preparedstatement.executeQuery();
		if (rss.next())

		{
			int tid = rss.getInt(1);
			Date date = rss.getDate(2);
			String priority = rss.getString(3);
			String customer = rss.getString(5);
			PreparedStatement ps1 = connection.prepareStatement("insert into ticket_table values(?,?,?,?,?,?,?,?)");
			ps1.setInt(1, tid);
			ps1.setString(2, priority);
			ps1.setDate(3, date);
			ps1.setDate(4, date);
			ps1.setString(5, "ongoing");
			ps1.setString(6, name);
			ps1.setString(7, customer);
			ps1.setDate(8, date);
			ps1.execute();
			PreparedStatement ps2 = connection.prepareStatement("delete from pendingtickets where Tid=?");
			ps2.setInt(1, tid);
			ps2.executeUpdate();
		}

	}

	public static List<serviceticket.Bean> viewAll() {
		List<serviceticket.Bean> alltickets = new ArrayList<serviceticket.Bean>();
		Database db = new Database();
		Connection connection = db.connection();
		try {
			PreparedStatement preparedstatement = connection.prepareStatement("select * from  ticket_table");
			ResultSet resultset = preparedstatement.executeQuery();
			serviceticket.Bean record = null;
			while (resultset.next()) {
				record = new serviceticket.Bean();
				record.setAcutal_priority(resultset.getString("Priority"));
				record.setStart_date(resultset.getDate("Start_date").toLocalDate());
				record.setCompleted_date(resultset.getDate("completed_date").toLocalDate());
				record.setTicket_id(resultset.getInt(1));
				record.setService_engineer(resultset.getString(6));
				record.setCustomer(resultset.getString(7));
				alltickets.add(record);
			}
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return alltickets;
	}

	public static List<serviceticket.Bean> viewPending() {
		List<serviceticket.Bean> alltickets = new ArrayList<serviceticket.Bean>();
		Database db = new Database();
		Connection connection = db.connection();
		try {
			PreparedStatement preparedstmt = connection.prepareStatement("select * from  pendingtickets");
			ResultSet resultset = preparedstmt.executeQuery();
			while (resultset.next()) {
				serviceticket.Bean record = new serviceticket.Bean();
				record.setTicket_id(resultset.getInt(1));
				record.setStart_date(resultset.getDate("Start_date").toLocalDate());
				record.setAcutal_priority(resultset.getString(3));
				record.setCustomer(resultset.getString(5));
				alltickets.add(record);
			}
			resultset.close();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return alltickets;
	}

	public static int ticketsAge(int ticketname) {
		Database db = new Database();
		Connection connection = db.connection();
		int newage = 0;
		try {
			PreparedStatement preparedstmt = connection.prepareStatement(
					"select   TIMESTAMPDIFF ( DAY, Start_date,CURDATE() ) from ticket_table  where Tid=? and Status=?");
			preparedstmt.setInt(1, ticketname);
			preparedstmt.setString(2, "ongoing");
			ResultSet age = preparedstmt.executeQuery();
			if (age.next()) {
				newage = age.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return newage;
	}

	public static int[] perSeverity() {
		Database database = new Database();
		Connection connection = database.connection();

		int array[] = new int[3];

		try {
			PreparedStatement preparedstmt = connection.prepareStatement(
					"select   AVG ( TIMESTAMPDIFF ( DAY, Start_date, completed_date)) from ticket_table where Status=? and Priority=?");
			preparedstmt.setString(1, "completed");
			preparedstmt.setString(2, "medium");
			ResultSet resultset = preparedstmt.executeQuery();
			if (resultset.next()) {
				array[1] = resultset.getInt(1);
			}
			PreparedStatement preparedstmt1 = connection.prepareStatement(
					"select   AVG ( TIMESTAMPDIFF ( DAY, Start_date, completed_date)) from ticket_table where Status=? and Priority=?");
			preparedstmt1.setString(1, "completed");
			preparedstmt1.setString(2, "low");
			ResultSet resultset1 = preparedstmt1.executeQuery();
			if (resultset1.next()) {
				array[0] = resultset1.getInt(1);
			}
			PreparedStatement preparedstmt2 = connection.prepareStatement(
					"select   AVG ( TIMESTAMPDIFF ( DAY, Start_date, completed_date)) from ticket_table where Status=? and Priority=?");
			preparedstmt2.setString(1, "completed");
			preparedstmt2.setString(2, "high");
			ResultSet resultset2 = preparedstmt2.executeQuery();
			if (resultset2.next()) {
				array[2] = resultset2.getInt(1);
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		return array;
	}

	public static int engineerSeverity(String name) {

		int severity = 0;
		try {
			Database database = new Database();
			Connection connection = database.connection();
			PreparedStatement preparedstmt = connection.prepareStatement(
					"select   AVG ( TIMESTAMPDIFF ( DAY, Start_date, completed_date)) from ticket_table where Status=? and Service_engineer=?;");
			preparedstmt.setString(1, "completed");
			preparedstmt.setString(2, name);
			ResultSet resultset = preparedstmt.executeQuery();
			if (resultset.next()) {
				severity = resultset.getInt(1);
			}
		} catch (Exception e) {
			e.getStackTrace();

		}
		return severity;
	}

}

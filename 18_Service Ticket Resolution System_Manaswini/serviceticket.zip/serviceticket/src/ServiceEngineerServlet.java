
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sun.print.resources.serviceui;

@WebServlet("/ServiceEngineerServlet")
public class ServiceEngineerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		String function = request.getParameter("varname");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		String user = (String) session.getAttribute("user");
		if (function.equals("complete")) {
			int tid = ServiceEngineerDao.completeTicket(user);
			ServiceEngineerDao.updateTicketStatus(tid, user);
			session.setAttribute("tid", tid);
			System.out.println(tid);
			LocalDate completed_date = LocalDate.now();
			RequestDispatcher rs = request.getRequestDispatcher("ticketcomplete.jsp");
			try {
				ServiceEngineerDao.assignPending(user);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
			rs.forward(request, response);
		} else if (function.equals("ticketsworked")) {
			List<serviceticket.Bean> ticketsworked = ServiceEngineerDao.view(user);
			session.setAttribute("ticketsworked", ticketsworked);
			RequestDispatcher rs = request.getRequestDispatcher("ticketsworkedtable.jsp");
			rs.forward(request, response);
		} else if (function.equals("alltickets")) {
			List<serviceticket.Bean> tickethistory = ServiceEngineerDao.viewAll();
			List<serviceticket.Bean> ticketspending = ServiceEngineerDao.viewPending();
			session.setAttribute("ticketshistory", tickethistory);
			session.setAttribute("ticketspending", ticketspending);
			RequestDispatcher rs = request.getRequestDispatcher("ticketshistory.jsp");
			rs.forward(request, response);
		} else if (function.equals("perseverity")) {
			int array[] = ServiceEngineerDao.perSeverity();
			session.setAttribute("low", array[0]);
			session.setAttribute("medium", array[1]);
			session.setAttribute("high", array[2]);
			RequestDispatcher rs = request.getRequestDispatcher("ticketsseverity.jsp");
			rs.forward(request, response);
		} else if (function.equals("ticketsage")) {
			RequestDispatcher rs = request.getRequestDispatcher("ticketage.jsp");
			rs.forward(request, response);
		} else if (function.equals("ticketname")) {
			int ticket = ServiceEngineerDao.ticketsAge(Integer.parseInt(request.getParameter("ticketname")));
			out.print("<html><body><h3 align:\"center\">Ticket Age is :" + ticket + " Day</h3></body></html>");
		} else if (function.equals("engineerseverity")) {
			RequestDispatcher rs = request.getRequestDispatcher("Engineername.jsp");
			rs.forward(request, response);
		} else if (function.equals("severitycheck")) {
			int severity = ServiceEngineerDao.engineerSeverity(request.getParameter("engineername"));
			out.print("<html><body><h3 align:\"center\">Severity of " + request.getParameter("engineername") + "is: "
					+ severity + " </h3></body></html>");
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
}
package serviceticket;

import java.sql.Date;
import java.time.LocalDate;

public class Bean {
	private int ticket_id;
	private String dept;
	private String prior;
	private String priority;
	private LocalDate start_date;
	private long end_date;
	private String description;
	private String customer;
	private String service_engineer;
	private String acutal_priority;
	private LocalDate completed_date;

	public int getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(int ticket_id) {
		this.ticket_id = ticket_id;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getPrior() {
		return prior;
	}

	public void setPrior(String prior) {
		this.prior = prior;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public LocalDate getStart_date() {
		return start_date;
	}

	public void setStart_date(LocalDate start_date) {
		this.start_date = start_date;
	}

	public long getEnd_date() {
		return end_date;
	}

	public void setEnd_date(long end_date) {
		this.end_date = end_date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public Bean(int ticket_id, String prior, String description, String customer, String service_engineer) {
		super();
		this.ticket_id = ticket_id;
		this.prior = prior;
		this.description = description;
		this.customer = customer;
		this.service_engineer = service_engineer;
	}

	public Bean() {
	}

	public Bean(int ticket_id, LocalDate start_date, LocalDate completed_date, String priority, String status,
			String service_engineer, String customer, String description) {
		this.description = description;
		this.customer = customer;
		this.service_engineer = service_engineer;
		this.acutal_priority = acutal_priority;
		this.start_date = start_date;
		this.completed_date = completed_date;
		this.priority = priority;
		this.ticket_id = ticket_id;

	}

	@Override
	public String toString() {
		return "Bean [ticket_id=" + ticket_id + ", dept=" + dept + ", prior=" + prior + ", priority=" + priority
				+ ", start_date=" + start_date + ", end_date=" + end_date + ", description=" + description
				+ ", customer=" + customer + ", service_engineer=" + service_engineer + ", acutal_priority="
				+ acutal_priority + ", completed_date=" + completed_date + "]";
	}

	public String getService_engineer() {
		return service_engineer;
	}

	public void setService_engineer(String service_engineer) {
		this.service_engineer = service_engineer;
	}

	public String getAcutal_priority() {
		return acutal_priority;
	}

	public void setAcutal_priority(String acutal_priority) {
		this.acutal_priority = acutal_priority;
	}

	public LocalDate getCompleted_date() {
		return completed_date;
	}

	public void setCompleted_date(LocalDate completed_date) {
		this.completed_date = completed_date;
	}

}

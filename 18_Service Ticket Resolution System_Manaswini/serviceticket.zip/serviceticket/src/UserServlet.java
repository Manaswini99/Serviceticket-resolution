import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String function = request.getParameter("varname");
		HttpSession session = request.getSession(false);
		if (function.equals("raiseticket")) {
			response.sendRedirect("raiseticket.jsp");
		} else if (function.equals("issues")) {
			Bean newticket = new Bean();
			String dept = request.getParameter("dept");
			int ticket_id = UserDao.createId();
			String description = request.getParameter("issue");
			String prior = UserDao.checkPriority(description);
			newticket.setEnd_date(request.getParameter("date"));
			LocalDate start_date = LocalDate.now();
			String priority = request.getParameter("priority");
			newticket.setCustomer((String) session.getAttribute("user"));
			newticket.setDept(request.getParameter("dept"));
			newticket.setTicket_id(UserDao.createId());
			newticket.setDescription(request.getParameter("issue"));
			newticket.setPrior(prior);
			newticket.setStart_date(LocalDate.now());
			newticket.setPriority(priority);
			if (priority.equals("low") && prior.equals("high")) {

				newticket.setAcutal_priority("low");

			} else {
				newticket.setAcutal_priority(prior);

			}
			System.out.println(UserDao.searchEngineer(newticket));
			String engineer = UserDao.searchEngineer(newticket);

			if (engineer == null) {
				int ticketid = UserDao.searchPriorityBasis(newticket);
				// System.out.println(ticketid);
				if (ticketid == ticket_id) {
					UserDao.pendingTicket(newticket);
				} else {
					UserDao.pendingTicket(ticketid);
				}
			} else {
				newticket.setService_engineer(engineer);
				UserDao.ticketIssue(newticket);
				UserDao.updateServiceEngineerTable(newticket);
			}
		} else {
			String user = (String) session.getAttribute("user");
			List tickets = UserDao.view(user);
			session.setAttribute("tickets", tickets);
			RequestDispatcher rs = request.getRequestDispatcher("viewtickets.jsp");
			rs.forward(request, response);
		}

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
}
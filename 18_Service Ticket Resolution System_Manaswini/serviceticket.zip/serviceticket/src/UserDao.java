import java.util.List;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;
import java.time.temporal.ChronoUnit;

public class UserDao {

	public static int createId() {
		Random rand = new Random();
		int num = rand.nextInt(9000000) + rand.nextInt(1000);
		return num;
	}

	public static boolean ticketIssue(Bean newticket) {
		Database db = new Database();
		Connection con = db.connection();
		try {
			String query = " insert into ticket_table(Tid,Priority,Start_date,Requested_end_date,Status,Service_engineer,customer,completed_date)"
					+ " values (?, ?, ?, ?,?,?,?,?)";
			java.sql.PreparedStatement preparedStmt = con.prepareStatement(query);
			preparedStmt.setInt(1, newticket.getTicket_id());
			preparedStmt.setDate(3, Date.valueOf(newticket.getStart_date()));
			preparedStmt.setString(2, newticket.getAcutal_priority());
			preparedStmt.setDate(4, Date.valueOf(newticket.getEnd_date()));
			preparedStmt.setString(5, "ongoing");
			preparedStmt.setString(6, newticket.getService_engineer());
			preparedStmt.setString(7, newticket.getCustomer());
			preparedStmt.setDate(8, Date.valueOf(newticket.getStart_date()));
			boolean i = preparedStmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	public static String checkPriority(String description) {
		String high[] = { "installation", "crash", "hardware", "software" };
		String medium[] = { "clean", "pendrive", "disk", "dirty" };
		String low[] = { "keyboard", "adapter", "dustbin" };
		for (int i = 0; i < high.length; i++) {
			if (description.contains(high[i])) {
				return "high";
			}
		}
		for (int i = 0; i < medium.length; i++) {
			if (description.contains(medium[i])) {
				return "medium";
			}
		}
		for (int i = 0; i < low.length; i++) {
			if (description.contains(low[i])) {
				return "low";
			}
		}
		return "low";
	}

	public static List<serviceticket.Bean> view(String user) {
		Database db = new Database();
		Connection con = db.connection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from  ticket_table");

			ResultSet rs = ps.executeQuery();

			List<serviceticket.Bean> tickets = new ArrayList<serviceticket.Bean>();
			while (rs.next()) {
				if (user.equals(rs.getString(7))) {
					tickets.add(new serviceticket.Bean(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(6),rs.getString(7)));
							
				}
			}
			System.out.println(tickets.get(0).getTicket_id());
			return tickets;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String searchEngineer(Bean newticket) {
		int tid = newticket.getTicket_id();
		String priority = newticket.getAcutal_priority();
		LocalDate date = newticket.getStart_date();
		Database db = new Database();
		Connection con = db.connection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from service_engineer");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getInt(5) == 0) {
					PreparedStatement ps1 = con
							.prepareStatement("update service_engineer set cuurent_highpriority=? where name=?");
					ps1.setInt(1, 1);
					ps1.setString(2, rs.getString(2));
					ps1.executeUpdate();
					return rs.getString(2);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void pendingTicket(Bean newticket) {
		int tid = newticket.getTicket_id();
		LocalDate date = newticket.getStart_date();
		LocalDate current_date = LocalDate.now();
		long daysBetween = ChronoUnit.DAYS.between(date, current_date);
		Database db = new Database();
		Connection con = db.connection();
		try {
			String query = " insert into pendingtickets(Tid,start_date,priority,count_of_days,customer)"
					+ " values (?, ?, ?, ?,?)";
			java.sql.PreparedStatement preparedStmt = con.prepareStatement(query);
			preparedStmt.setInt(1, newticket.getTicket_id());
			preparedStmt.setDate(2, Date.valueOf(newticket.getStart_date()));
			preparedStmt.setString(3, newticket.getAcutal_priority());
			preparedStmt.setInt(4, (int) daysBetween);
			preparedStmt.setString(5, newticket.getCustomer());
			preparedStmt.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static int searchPriorityBasis(Bean newticket) {
		Database db = new Database();
		Connection con = db.connection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from ticket_table");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (newticket.getAcutal_priority().equals("high") && rs.getString(2).equals("low")
						&& rs.getString(5).equals("ongoing")) {
					return rs.getInt(1);
				} else if (newticket.getAcutal_priority().equals("high") && rs.getString(2).equals("medium")
						&& rs.getString(5).equals("ongoing")) {
					return rs.getInt(1);
				} else if (newticket.getAcutal_priority().equals("medium") && rs.getString(2).equals("low")
						&& rs.getString(5).equals("ongoing")) {
					return rs.getInt(1);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return newticket.getTicket_id();
	}

	public static void updateServiceEngineerTable(Bean newticket) {
		Database db = new Database();
		Connection con = db.connection();
		try {
			PreparedStatement ps = con
					.prepareStatement("update service_engineer set cuurent_highpriority=? where id=?");
			String pri = newticket.getAcutal_priority();
			int i;
			if (pri.equals("high")) {
				i = 1;
			} else if (pri.equals("medium")) {
				i = 2;
			} else {
				i = 3;
			}
			ps.setInt(1, i);
			ps.setString(2, newticket.getService_engineer());
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void pendingTicket(int ticketid) {
		Database db = new Database();
		Connection con = db.connection();
		try {
			PreparedStatement ps = con.prepareStatement("select * from ticket_table");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getInt(1) == ticketid) {
					Date d = rs.getDate(3);
					String priority = rs.getString(2);
					String customer = rs.getString(7);
					String query = " insert into pendingtickets(Tid,start_date,priority,count_of_days,customer)"
							+ " values (?, ?, ?, ?,?)";
					java.sql.PreparedStatement preparedStmt = con.prepareStatement(query);
					preparedStmt.setInt(1, ticketid);
					preparedStmt.setDate(2, d);
					preparedStmt.setString(3, priority);
					preparedStmt.setInt(4, 0);
					preparedStmt.setString(5, customer);
					preparedStmt.execute();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
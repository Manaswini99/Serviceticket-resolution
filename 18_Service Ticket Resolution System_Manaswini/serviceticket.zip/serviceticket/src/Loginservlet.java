
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		String user = request.getParameter("user");
		String pass = request.getParameter("pass");
		session.setAttribute("user", user);
		session.setAttribute("pass", pass);
		if (Ldoa.checkSe(user, pass)) {
			out.print(user);
			RequestDispatcher rs = request.getRequestDispatcher("ServiceEngineer.jsp");
			rs.forward(request, response);
			out.println(pass);
		} else if (Ldoa.checkUser(user, pass)) {
			response.sendRedirect("User.jsp");

		} else {

			out.println("Username or Password incorrect");
			RequestDispatcher rs = request.getRequestDispatcher("Login.jsp");
			rs.include(request, response);
		}

	}

}
